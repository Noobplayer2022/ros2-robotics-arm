#!/usr/bin/env python3
import time
import numpy as np

import rclpy
from rclpy.node import Node
from sensor_msgs.msg import JointState
from trajectory_msgs.msg import JointTrajectory, JointTrajectoryPoint
from std_msgs.msg import Bool
from builtin_interfaces.msg import Duration
import tf2_ros

import config


class ArmController:
    def __init__(self, detector: Node):
        self.node = detector  # از نود مشترک perception استفاده می‌کنیم
        self.detector = detector
        self.get_logger = detector.get_logger

        self.tf_buffer = detector.tf_buffer
        self.ee_link = config.TIP_LINK

        self.current_joint_positions = None
        self.node.create_subscription(JointState, "/joint_states", self.joint_state_callback, 5)
        self.traj_pub = self.node.create_publisher(JointTrajectory, config.CONTROLLER_TOPIC, 1)

        self.magnet_attached = False
        self.magnet_pub = self.node.create_publisher(Bool, config.MAGNET_ATTACH_TOPIC, 1)
        self.node.create_subscription(Bool, config.MAGNET_STATUS_TOPIC, self._magnet_status_cb, 5)

        self.enabled = False
        self.node.create_subscription(Bool, config.ARM_ENABLED_TOPIC, self._arm_enabled_cb, 1)

        time.sleep(1.0)
        self.go_home()

    def _arm_enabled_cb(self, msg):
        was = self.enabled
        self.enabled = msg.data
        if self.enabled and not was:
            self.get_logger().info("Arm ENABLED")
        elif not self.enabled and was:
            self.get_logger().info("Arm DISABLED")
            m = Bool(); m.data = False
            self.magnet_pub.publish(m)

    def joint_state_callback(self, msg):
        try:
            self.current_joint_positions = [msg.position[msg.name.index(j)] for j in config.JOINT_NAMES]
        except ValueError:
            pass

    def in_workspace(self, x, y, z):
        r = np.sqrt(x * x + y * y)
        return (config.MIN_RADIUS <= r <= config.MAX_RADIUS) and (config.MIN_Z <= z <= config.MAX_Z)

    def stream_setpoint(self, joint_target):
        if self.current_joint_positions is None:
            return
        current = np.array(self.current_joint_positions)
        target = np.array(joint_target)
        error = target - current
        velocity_cmd = np.clip(config.TRACK_KP * error, -config.MAX_JOINT_VEL, config.MAX_JOINT_VEL)
        next_positions = current + velocity_cmd * config.STREAM_DT
        next_positions = current + np.clip(
            next_positions - current, -config.JOINT_STEP_LIMIT, config.JOINT_STEP_LIMIT)

        traj = JointTrajectory()
        traj.joint_names = list(config.JOINT_NAMES)
        pt = JointTrajectoryPoint()
        pt.positions = next_positions.tolist()
        pt.velocities = velocity_cmd.tolist()
        pt.time_from_start = Duration(sec=0, nanosec=int(config.TRAJ_POINT_HORIZON * 1e9))
        traj.points = [pt]
        self.traj_pub.publish(traj)

    def send_joints(self, joints, duration=2.0):
        traj = JointTrajectory()
        traj.joint_names = list(config.JOINT_NAMES)
        pt = JointTrajectoryPoint()
        pt.positions = list(joints)
        pt.time_from_start = Duration(sec=int(duration), nanosec=int((duration % 1) * 1e9))
        traj.points = [pt]
        self.traj_pub.publish(traj)
        time.sleep(duration + 0.3)

    def go_home(self):
        self.send_joints(config.HOME_JOINTS, 2.0)
        return True

    def go_ready(self):
        self.send_joints(config.READY_JOINTS, 2.0)
        return True

    def _magnet_status_cb(self, msg):
        self.magnet_attached = msg.data

    def set_gripper(self, open_gripper: bool):
        m = Bool()
        m.data = not open_gripper
        self.magnet_pub.publish(m)

    def run_forever(self):
        self.get_logger().info("=== track+grasp loop (idle until enabled) ===")
        rate_hz = config.CONTROL_RATE
        period = 1.0 / rate_hz
        was_enabled = False
        seed = self.current_joint_positions or config.READY_JOINTS

        while rclpy.ok():
            if not self.enabled:
                was_enabled = False
                time.sleep(period)
                continue

            if not was_enabled:
                self.get_logger().info("Arm active -- ready pose")
                self.go_ready()
                seed = self.current_joint_positions or config.READY_JOINTS
                was_enabled = True

            if self.magnet_attached:
                self.get_logger().info("Cube attached -- transport")
                self.transport_and_release()
                self.detector.reset_tracking()
                seed = self.current_joint_positions or config.READY_JOINTS
                time.sleep(period)
                continue

            m = Bool(); m.data = True
            self.magnet_pub.publish(m)

            target = self.detector.predict_setpoint(config.TRACK_LEAD_TIME)
            if target is None:
                time.sleep(period)
                continue
            x, y, z = target
            approach_z = config.SAFE_HOVER_Z
            if not self.in_workspace(x, y, approach_z):
                time.sleep(period)
                continue

            # بدون TRAC-IK: فقط ready/stream با seed فعلی
            # اگر IK جدا داری اینجا جایگزین کن
            self.stream_setpoint(seed)
            time.sleep(period)

    def transport_and_release(self):
        base = list(self.current_joint_positions) if self.current_joint_positions else list(config.READY_JOINTS)
        rotated = list(base)
        rotated[0] = float(np.clip(base[0] + (np.pi / 2.0), config.JOINT1_MIN, config.JOINT1_MAX))
        self.send_joints(rotated, 2.0)
        self.set_gripper(True)
        self.go_home()