#!/usr/bin/env python3
import threading
import numpy as np
import cv2

import rclpy
from rclpy.node import Node
from rclpy.qos import QoSProfile, ReliabilityPolicy, HistoryPolicy
from sensor_msgs.msg import Image
from geometry_msgs.msg import PointStamped, PoseStamped
from std_msgs.msg import String
from cv_bridge import CvBridge
import tf2_ros
from tf2_geometry_msgs import do_transform_point

import config


class CubeDetector(Node):
    def __init__(self):
        super().__init__("cube_detector")
        self.bridge = CvBridge()
        self.depth_image = None
        self.target_frame = config.BASE_LINK

        self.kf = cv2.KalmanFilter(6, 3)
        self.kf.measurementMatrix = np.array([
            [1, 0, 0, 0, 0, 0],
            [0, 1, 0, 0, 0, 0],
            [0, 0, 1, 0, 0, 0]], np.float32)
        self.kf.transitionMatrix = np.array([
            [1, 0, 0, 1, 0, 0],
            [0, 1, 0, 0, 1, 0],
            [0, 0, 1, 0, 0, 1],
            [0, 0, 0, 1, 0, 0],
            [0, 0, 0, 0, 1, 0],
            [0, 0, 0, 0, 0, 1]], np.float32)
        self.kf.processNoiseCov = np.eye(6, dtype=np.float32) * 0.05
        self.kf.measurementNoiseCov = np.eye(3, dtype=np.float32) * 0.03
        self.kf.errorCovPost = np.eye(6, dtype=np.float32)
        self.kf.statePost = np.zeros((6, 1), np.float32)
        self.kf_initialized = False

        self.history = []
        self.last_seen_time = None
        self.state_lock = threading.Lock()

        self.color_ranges = {
            'blue': {'lower': np.array([100, 50, 50]), 'upper': np.array([130, 255, 255])},
            'green': {'lower': np.array([40, 50, 50]), 'upper': np.array([80, 255, 255])},
            'red': {'lower': np.array([0, 50, 50]), 'upper': np.array([10, 255, 255])},
        }
        self.red_range2_lower = np.array([170, 50, 50])
        self.red_range2_upper = np.array([180, 255, 255])

        self.enabled_colors = {"red", "green", "blue"}
        self.create_subscription(String, config.ENABLED_COLORS_TOPIC, self._enabled_colors_cb, 1)

        self.fx = 554.25469
        self.fy = 554.25469
        self.cx = 320.5
        self.cy = 240.5
        self.camera_matrix = np.array([
            [self.fx, 0, self.cx],
            [0, self.fy, self.cy],
            [0, 0, 1]], dtype=np.float64)
        self.dist_coeffs = np.zeros(5)

        self.tf_buffer = tf2_ros.Buffer()
        self.tf_listener = tf2_ros.TransformListener(self.tf_buffer, self)

        self.debug_pose_pub = self.create_publisher(PoseStamped, "/cube/pose", 5)

        qos = QoSProfile(
            reliability=ReliabilityPolicy.BEST_EFFORT,
            history=HistoryPolicy.KEEP_LAST,
            depth=1,
        )
        self.create_subscription(Image, config.CAMERA_RGB_TOPIC, self.rgb_callback, qos)
        self.create_subscription(Image, config.CAMERA_DEPTH_TOPIC, self.depth_callback, qos)

    def _enabled_colors_cb(self, msg):
        colors = {c.strip().lower() for c in msg.data.split(",") if c.strip()}
        self.enabled_colors = colors & {"red", "green", "blue"}
        self.get_logger().info(f"Enabled colors: {sorted(self.enabled_colors) if self.enabled_colors else '(none)'}")

    def reset_tracking(self):
        self.kf.statePost = np.zeros((6, 1), np.float32)
        self.kf.errorCovPost = np.eye(6, dtype=np.float32)
        self.kf_initialized = False
        with self.state_lock:
            self.history = []
            self.last_seen_time = None

    def depth_callback(self, msg):
        try:
            self.depth_image = self.bridge.imgmsg_to_cv2(msg, "32FC1")
        except Exception:
            pass

    def rgb_callback(self, msg):
        try:
            image = self.bridge.imgmsg_to_cv2(msg, "bgr8")
        except Exception:
            return
        self.process(image)

    def detect_colors(self, hsv):
        detections = []
        for color_name, data in self.color_ranges.items():
            mask = cv2.inRange(hsv, data['lower'], data['upper'])
            if color_name == "red":
                mask2 = cv2.inRange(hsv, self.red_range2_lower, self.red_range2_upper)
                mask = cv2.bitwise_or(mask, mask2)
            kernel = np.ones((5, 5), np.uint8)
            mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN, kernel)
            mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, kernel)
            contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
            for c in contours:
                area = cv2.contourArea(c)
                if area < 600:
                    continue
                M = cv2.moments(c)
                if M["m00"] == 0:
                    continue
                cx = int(M["m10"] / M["m00"])
                cy = int(M["m01"] / M["m00"])
                detections.append({"color": color_name, "center": (cx, cy), "area": area, "contour": c})
        return detections

    def get_pose_solvepnp(self, contour):
        rect = cv2.minAreaRect(contour)
        box = cv2.boxPoints(rect).astype(np.float64)
        s = box.sum(axis=1)
        diff = np.diff(box, axis=1).flatten()
        ordered = np.zeros((4, 2), dtype=np.float64)
        ordered[0] = box[np.argmin(s)]
        ordered[2] = box[np.argmax(s)]
        ordered[1] = box[np.argmin(diff)]
        ordered[3] = box[np.argmax(diff)]
        half = config.CUBE_SIZE_M / 2.0
        object_points = np.array([
            [-half, -half, 0], [half, -half, 0],
            [half, half, 0], [-half, half, 0]], dtype=np.float64)
        try:
            ok, rvec, tvec = cv2.solvePnP(
                object_points, ordered, self.camera_matrix, self.dist_coeffs,
                flags=cv2.SOLVEPNP_IPPE_SQUARE)
            if not ok:
                return None
            return float(tvec[0]), float(tvec[1]), float(tvec[2])
        except Exception:
            return None

    def calculate_3d(self, cx, cy, depth):
        if depth is None or depth <= 0 or np.isnan(depth):
            return None
        X = (cx - self.cx) * depth / self.fx
        Y = (cy - self.cy) * depth / self.fy
        Z = depth
        return (X, Y, Z)

    def transform_to_world(self, point):
        try:
            # optical -> camera link (Gazebo convention)
            X_opt, Y_opt, Z_opt = point
            p = PointStamped()
            p.header.frame_id = config.CAMERA_FRAME
            p.header.stamp = rclpy.time.Time().to_msg()
            p.point.x = Z_opt
            p.point.y = -X_opt
            p.point.z = -Y_opt
            tf = self.tf_buffer.lookup_transform(
                self.target_frame, config.CAMERA_FRAME, rclpy.time.Time())
            return do_transform_point(p, tf)
        except Exception as e:
            self.get_logger().warn(f"TF error: {e}", throttle_duration_sec=2.0)
            return None

    def process(self, image):
        hsv = cv2.cvtColor(image, cv2.COLOR_BGR2HSV)
        detections = self.detect_colors(hsv)
        detections = [d for d in detections if d["color"] in self.enabled_colors]
        if not detections:
            now = self.get_clock().now()
            if self.last_seen_time is not None:
                age = (now - self.last_seen_time).nanoseconds * 1e-9
                if age > config.MAX_TRACK_AGE:
                    self.reset_tracking()
            return

        det = max(detections, key=lambda d: d['area'])
        cx, cy = det["center"]
        color = det["color"]

        p3d = self.get_pose_solvepnp(det["contour"])
        if p3d is None and self.depth_image is not None:
            try:
                depth = float(self.depth_image[cy, cx])
                p3d = self.calculate_3d(cx, cy, depth)
            except Exception:
                p3d = None
        # fallback بدون depth: فرض فاصله ثابت روی سطح نوار
        if p3d is None:
            assumed_z = 0.8  # متر در فریم دوربین — در صورت نیاز تنظیم کن
            p3d = self.calculate_3d(cx, cy, assumed_z)
        if p3d is None:
            return

        X, Y, Z = p3d
        if not self.kf_initialized:
            self.kf.statePost = np.array([[X], [Y], [Z], [0], [0], [0]], np.float32)
            self.kf.errorCovPost = np.eye(6, dtype=np.float32) * 0.1
            self.kf_initialized = True

        measurement = np.array([[np.float32(X)], [np.float32(Y)], [np.float32(Z)]])
        self.kf.correct(measurement)
        prediction = self.kf.predict()
        X, Y, Z = float(prediction[0]), float(prediction[1]), float(prediction[2])

        world = self.transform_to_world((X, Y, Z))
        if world is None:
            return

        wx, wy, wz = world.point.x, world.point.y, world.point.z
        now = self.get_clock().now()
        tsec = now.nanoseconds * 1e-9

        with self.state_lock:
            self.history.append((tsec, wx, wy, wz))
            if len(self.history) > config.HISTORY_MAXLEN:
                self.history.pop(0)
            self.last_seen_time = now

        pose_msg = PoseStamped()
        pose_msg.header.frame_id = self.target_frame
        pose_msg.header.stamp = now.to_msg()
        pose_msg.pose.position.x = wx
        pose_msg.pose.position.y = wy
        pose_msg.pose.position.z = wz
        pose_msg.pose.orientation.w = 1.0
        self.debug_pose_pub.publish(pose_msg)
        self.get_logger().info(f"[{color}] base_link: x={wx:.3f} y={wy:.3f} z={wz:.3f}", throttle_duration_sec=1.0)

    def get_velocity_and_position(self):
        with self.state_lock:
            hist = list(self.history)
        if len(hist) < config.MIN_HISTORY_POINTS:
            if len(hist) >= 1:
                t_last, x_last, y_last, z_last = hist[-1]
                return t_last, np.array([x_last, y_last, z_last]), np.zeros(3)
            return None
        arr = np.array(hist)
        t = arr[:, 0]
        span = t[-1] - t[0]
        if span < config.MIN_HISTORY_SPAN:
            t_last, x_last, y_last, z_last = hist[-1]
            return t_last, np.array([x_last, y_last, z_last]), np.zeros(3)

        t_ref = t[-1]
        t_rel = t - t_ref
        vel = np.zeros(3)
        for i, axis in enumerate([1, 2, 3]):
            coeffs = np.polyfit(t_rel, arr[:, axis], 1)
            vel[i] = coeffs[0]

        speed = np.linalg.norm(vel)
        if speed > config.MAX_BELT_SPEED:
            vel = vel * (config.MAX_BELT_SPEED / speed)

        pos = np.array([arr[-1, 1], arr[-1, 2], arr[-1, 3]])
        return t_ref, pos, vel

    def predict_setpoint(self, lead_time):
        fit = self.get_velocity_and_position()
        if fit is None:
            return None
        t_ref, pos, vel = fit
        age = self.get_clock().now().nanoseconds * 1e-9 - t_ref
        dt = age + lead_time
        predicted = pos + vel * dt
        return predicted[0], predicted[1], predicted[2]